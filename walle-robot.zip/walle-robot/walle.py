#!/usr/bin/env python3
"""
WALL-E Robot Controller
========================
Raspberry Pi - Full Control System
Author  : Your Name
Version : 1.0.0
License : MIT
"""

import RPi.GPIO as GPIO
import time
import threading
import pygame
import random
from gpiozero import Servo, DistanceSensor
from luma.oled import device as oled_device
from luma.core.interface.serial import i2c
from luma.core.render import canvas
from PIL import ImageFont

# ─────────────────────────────────────────
# إعداد GPIO
# ─────────────────────────────────────────
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)


# ═══════════════════════════════════════════
# 1. إعداد المحركات (L298N Motor Driver)
# ═══════════════════════════════════════════
class MotorController:
    def __init__(self):
        # المحرك الأيسر
        self.LEFT_IN1  = 17
        self.LEFT_IN2  = 18
        self.LEFT_ENA  = 12  # PWM

        # المحرك الأيمن
        self.RIGHT_IN3 = 22
        self.RIGHT_IN4 = 23
        self.RIGHT_ENB = 13  # PWM

        pins = [self.LEFT_IN1, self.LEFT_IN2, self.LEFT_ENA,
                self.RIGHT_IN3, self.RIGHT_IN4, self.RIGHT_ENB]
        for pin in pins:
            GPIO.setup(pin, GPIO.OUT)

        self.pwm_left  = GPIO.PWM(self.LEFT_ENA,  1000)
        self.pwm_right = GPIO.PWM(self.RIGHT_ENB, 1000)
        self.pwm_left.start(0)
        self.pwm_right.start(0)

    def _set_motor(self, in1, in2, pwm, speed):
        """speed: -100 إلى 100"""
        if speed > 0:
            GPIO.output(in1, GPIO.HIGH)
            GPIO.output(in2, GPIO.LOW)
        elif speed < 0:
            GPIO.output(in1, GPIO.LOW)
            GPIO.output(in2, GPIO.HIGH)
        else:
            GPIO.output(in1, GPIO.LOW)
            GPIO.output(in2, GPIO.LOW)
        pwm.ChangeDutyCycle(abs(speed))

    def forward(self, speed=70):
        self._set_motor(self.LEFT_IN1,  self.LEFT_IN2,  self.pwm_left,  speed)
        self._set_motor(self.RIGHT_IN3, self.RIGHT_IN4, self.pwm_right, speed)
        print(f"⬆️  Moving Forward  | Speed: {speed}%")

    def backward(self, speed=70):
        self._set_motor(self.LEFT_IN1,  self.LEFT_IN2,  self.pwm_left,  -speed)
        self._set_motor(self.RIGHT_IN3, self.RIGHT_IN4, self.pwm_right, -speed)
        print(f"⬇️  Moving Backward | Speed: {speed}%")

    def turn_left(self, speed=60):
        self._set_motor(self.LEFT_IN1,  self.LEFT_IN2,  self.pwm_left,  -speed)
        self._set_motor(self.RIGHT_IN3, self.RIGHT_IN4, self.pwm_right,  speed)
        print(f"◀️  Turning Left    | Speed: {speed}%")

    def turn_right(self, speed=60):
        self._set_motor(self.LEFT_IN1,  self.LEFT_IN2,  self.pwm_left,   speed)
        self._set_motor(self.RIGHT_IN3, self.RIGHT_IN4, self.pwm_right, -speed)
        print(f"▶️  Turning Right   | Speed: {speed}%")

    def stop(self):
        self._set_motor(self.LEFT_IN1,  self.LEFT_IN2,  self.pwm_left,  0)
        self._set_motor(self.RIGHT_IN3, self.RIGHT_IN4, self.pwm_right, 0)
        print("🛑 Stopped")

    def cleanup(self):
        self.pwm_left.stop()
        self.pwm_right.stop()


# ═══════════════════════════════════════════
# 2. إعداد السيرفو (الرأس والذراعين)
# ═══════════════════════════════════════════
class ServoController:
    def __init__(self):
        self.head_pan   = Servo(5)   # يمين/يسار
        self.head_tilt  = Servo(6)   # أعلى/أسفل
        self.arm_left   = Servo(19)  # الذراع الأيسر
        self.arm_right  = Servo(26)  # الذراع الأيمن

    def _clamp(self, val):
        return max(-1, min(1, val))

    def look_left(self):
        self.head_pan.value = self._clamp(-0.7)
        print("👀 Looking Left")

    def look_right(self):
        self.head_pan.value = self._clamp(0.7)
        print("👀 Looking Right")

    def look_center(self):
        self.head_pan.value  = 0
        self.head_tilt.value = 0
        print("👀 Looking Center")

    def nod_yes(self):
        print("🙆 Nodding Yes")
        for _ in range(3):
            self.head_tilt.value = 0.5
            time.sleep(0.3)
            self.head_tilt.value = -0.2
            time.sleep(0.3)
        self.head_tilt.value = 0

    def shake_no(self):
        print("🙅 Shaking No")
        for _ in range(3):
            self.head_pan.value = 0.6
            time.sleep(0.25)
            self.head_pan.value = -0.6
            time.sleep(0.25)
        self.head_pan.value = 0

    def raise_arms(self):
        self.arm_left.value  =  0.8
        self.arm_right.value = -0.8
        print("🙌 Arms Raised")

    def lower_arms(self):
        self.arm_left.value  = -0.3
        self.arm_right.value =  0.3
        print("💪 Arms Lowered")

    def wave(self):
        print("👋 Waving!")
        for _ in range(4):
            self.arm_right.value = -0.9
            time.sleep(0.2)
            self.arm_right.value = -0.3
            time.sleep(0.2)
        self.arm_right.value = -0.3

    def curious_look(self):
        """حركة تعبيرية: WALL-E فضولي"""
        self.head_tilt.value = 0.4
        self.head_pan.value  = 0.3
        time.sleep(1)
        self.head_pan.value  = -0.3
        time.sleep(0.5)
        self.look_center()


# ═══════════════════════════════════════════
# 3. شاشة OLED (الصدر)
# ═══════════════════════════════════════════
class ChestDisplay:
    def __init__(self):
        try:
            serial = i2c(port=1, address=0x3C)
            self.device = oled_device.ssd1306(serial, width=128, height=64)
            self.font = ImageFont.load_default()
            self.available = True
        except Exception:
            print("⚠️  OLED not found — skipping display")
            self.available = False

    def show_battery(self, level=85):
        if not self.available:
            return
        with canvas(self.device) as draw:
            draw.text((10, 5),  "WALL-E v1.0",       font=self.font, fill="white")
            draw.text((10, 20), f"Battery: {level}%", font=self.font, fill="white")
            bar_w = int(level * 1.0)
            draw.rectangle([10, 40, 10 + bar_w, 55], fill="white")
            draw.rectangle([10, 40, 110, 55], outline="white")

    def show_emotion(self, emotion="happy"):
        if not self.available:
            return
        faces = {
            "happy":     "^_^",
            "sad":       "T_T",
            "curious":   "o_O",
            "surprised": "O_O",
            "love":      "<3 ",
        }
        with canvas(self.device) as draw:
            draw.text((40, 25), faces.get(emotion, "•_•"),
                      font=self.font, fill="white")

    def show_text(self, text):
        if not self.available:
            return
        with canvas(self.device) as draw:
            draw.text((10, 25), text, font=self.font, fill="white")

    def clear(self):
        if self.available:
            self.device.clear()


# ═══════════════════════════════════════════
# 4. مستشعر المسافة (تجنب العوائق)
# ═══════════════════════════════════════════
class ObstacleDetector:
    def __init__(self):
        self.sensor = DistanceSensor(echo=24, trigger=25, max_distance=3)

    def get_distance(self):
        return round(self.sensor.distance * 100, 1)  # بالسنتيمتر

    def is_obstacle_ahead(self, threshold=30):
        dist = self.get_distance()
        if dist < threshold:
            print(f"🚧 Obstacle detected at {dist} cm!")
            return True
        return False


# ═══════════════════════════════════════════
# 5. نظام الصوت
# ═══════════════════════════════════════════
class SoundSystem:
    def __init__(self):
        pygame.mixer.init()
        self.sounds = {
            "hello":   "sounds/hello.wav",
            "happy":   "sounds/happy.wav",
            "sad":     "sounds/sad.wav",
            "working": "sounds/working.wav",
            "alarm":   "sounds/alarm.wav",
        }

    def play(self, sound_name):
        path = self.sounds.get(sound_name)
        if path:
            try:
                pygame.mixer.Sound(path).play()
                print(f"🔊 Playing: {sound_name}")
            except Exception as e:
                print(f"⚠️  Sound error: {e}")

    def beep(self, times=1):
        for _ in range(times):
            print("🔔 *beep*")
            time.sleep(0.1)


# ═══════════════════════════════════════════
# 6. الكلاس الرئيسي — WALL-E Robot
# ═══════════════════════════════════════════
class WallE:
    def __init__(self):
        print("🤖 Initializing WALL-E...")
        self.motors   = MotorController()
        self.servos   = ServoController()
        self.display  = ChestDisplay()
        self.detector = ObstacleDetector()
        self.sound    = SoundSystem()
        self.running  = True
        print("✅ WALL-E is ready!\n")

    def greet(self):
        print("👋 Greeting!")
        self.sound.play("hello")
        self.display.show_emotion("happy")
        self.servos.wave()
        self.servos.nod_yes()
        time.sleep(0.5)
        self.display.show_text("Hello!")

    def express_curiosity(self):
        print("🔍 Curious mode")
        self.display.show_emotion("curious")
        self.sound.beep(2)
        self.servos.curious_look()

    def express_happiness(self):
        self.display.show_emotion("happy")
        self.sound.play("happy")
        self.servos.raise_arms()
        time.sleep(0.5)
        self.servos.lower_arms()

    def autonomous_mode(self, duration=30):
        print(f"🚗 Autonomous mode for {duration}s")
        self.display.show_text("AUTO MODE")
        end_time = time.time() + duration

        while time.time() < end_time and self.running:
            if self.detector.is_obstacle_ahead(threshold=25):
                self.motors.stop()
                self.sound.beep(2)
                self.display.show_emotion("surprised")
                time.sleep(0.3)
                if random.choice([True, False]):
                    self.motors.turn_left(60)
                else:
                    self.motors.turn_right(60)
                time.sleep(0.6)
            else:
                self.motors.forward(65)
            time.sleep(0.1)

        self.motors.stop()
        print("🏁 Autonomous mode ended")

    def manual_control(self):
        print("\n🎮 Manual Control Mode")
        print("  W = Forward  | S = Backward")
        print("  A = Left     | D = Right")
        print("  G = Greet    | C = Curious")
        print("  H = Happy    | Space = Stop")
        print("  Q = Quit\n")
        self.display.show_text("MANUAL MODE")

        import sys, tty, termios
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            while self.running:
                key = sys.stdin.read(1).lower()
                if   key == 'w': self.motors.forward()
                elif key == 's': self.motors.backward()
                elif key == 'a': self.motors.turn_left()
                elif key == 'd': self.motors.turn_right()
                elif key == ' ': self.motors.stop()
                elif key == 'g': self.greet()
                elif key == 'c': self.express_curiosity()
                elif key == 'h': self.express_happiness()
                elif key == 'q':
                    self.running = False
                    break
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)

    def shutdown(self):
        print("\n🔴 Shutting down WALL-E...")
        self.motors.stop()
        self.servos.look_center()
        self.servos.lower_arms()
        self.display.show_text("Bye! :)")
        time.sleep(1)
        self.display.clear()
        self.motors.cleanup()
        GPIO.cleanup()
        print("✅ Shutdown complete.")


# ═══════════════════════════════════════════
# 7. نقطة الانطلاق
# ═══════════════════════════════════════════
if __name__ == "__main__":
    wall_e = WallE()
    try:
        wall_e.greet()
        time.sleep(1)
        # غيّر الوضع حسب رغبتك:
        # wall_e.autonomous_mode(duration=60)
        wall_e.manual_control()
    except KeyboardInterrupt:
        print("\n⚠️  Interrupted by user")
    finally:
        wall_e.shutdown()
