# 🤖 WALL-E Robot — Raspberry Pi

> A full-featured WALL-E robot controller built with Raspberry Pi, featuring motor control, servo animations, OLED display, obstacle avoidance, and sound playback.

![WALL-E](docs/walle_banner.jpg)

---

## ✨ Features

- 🚗 **Motor Control** — Forward, backward, left, right via L298N driver
- 🦾 **Servo Animations** — Head pan/tilt, arm raise/wave, curious look
- 📺 **OLED Chest Display** — Shows emotions, battery level, and status text
- 🔊 **Sound System** — Plays WAV sound effects via pygame
- 🚧 **Obstacle Avoidance** — Ultrasonic sensor (HC-SR04) for autonomous mode
- 🎮 **Manual Control** — Keyboard control via terminal

---

## 🛒 Components

| Component | Description |
|---|---|
| Raspberry Pi 4 | Main controller |
| L298N Motor Driver | Controls the tank treads |
| Servo Motors × 4 | Head (pan + tilt), Left arm, Right arm |
| HC-SR04 Ultrasonic | Obstacle detection |
| SSD1306 OLED (128×64) | Chest display (I2C) |
| Speaker + Amplifier | Sound output |
| 3D Printed Frame | WALL-E body (see `/models`) |

---

## 📌 GPIO Pin Map

| Component | GPIO Pin |
|---|---|
| Motor Left IN1 / IN2 | 17, 18 |
| Motor Left ENA (PWM) | 12 |
| Motor Right IN3 / IN4 | 22, 23 |
| Motor Right ENB (PWM) | 13 |
| Servo Head Pan | 5 |
| Servo Head Tilt | 6 |
| Servo Arm Left | 19 |
| Servo Arm Right | 26 |
| Ultrasonic TRIG / ECHO | 25, 24 |
| OLED SDA / SCL | GPIO 2, GPIO 3 |

---

## 🚀 Installation

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/walle-robot.git
cd walle-robot

# 2. Install dependencies
pip install -r requirements.txt

# 3. Enable I2C on Raspberry Pi
sudo raspi-config  # → Interface Options → I2C → Enable

# 4. Add sound files to /sounds folder
#    (hello.wav, happy.wav, sad.wav, working.wav, alarm.wav)

# 5. Run!
python3 walle.py
```

---

## 🎮 Controls (Manual Mode)

| Key | Action |
|---|---|
| `W` | Move Forward |
| `S` | Move Backward |
| `A` | Turn Left |
| `D` | Turn Right |
| `Space` | Stop |
| `G` | Greet (wave + sound) |
| `C` | Curious expression |
| `H` | Happy expression |
| `Q` | Quit |

---

## 🗂️ Project Structure

```
walle-robot/
├── walle.py            # Main robot controller
├── requirements.txt    # Python dependencies
├── sounds/             # WAV sound files (add your own)
│   ├── hello.wav
│   ├── happy.wav
│   ├── sad.wav
│   ├── working.wav
│   └── alarm.wav
├── models/             # 3D print files (.stl)
└── docs/               # Images and documentation
```

---

## 🖨️ 3D Printing

STL files for the WALL-E body are in the `/models` folder.
You can also find community models on [Thingiverse](https://www.thingiverse.com/search?q=wall-e).

Recommended settings:
- Layer height: **0.2mm**
- Infill: **20%**
- Supports: **Yes** (for overhangs)
- Material: **PLA or PETG**

---

## 🔮 Roadmap

- [ ] Web interface for remote control (Flask)
- [ ] OpenCV face/object detection
- [ ] Bluetooth mobile app control
- [ ] Voice command recognition
- [ ] Solar charging integration

---

## 📄 License

MIT License — free to use, modify, and share.

---

## 🙏 Credits

Inspired by the WALL-E character by Pixar/Disney.
Built with ❤️ using Raspberry Pi and Python.
